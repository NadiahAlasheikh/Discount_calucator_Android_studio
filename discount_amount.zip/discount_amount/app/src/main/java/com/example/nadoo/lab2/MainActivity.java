package com.example.nadoo.lab2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void send(View view) {
        EditText editText1 = (EditText) findViewById(R.id.editText);
        EditText editText2 = (EditText) findViewById(R.id.editText2);

        String data1 = editText1.getText().toString();
        String data2 = editText2.getText().toString();
        double num1 = Double.parseDouble(data1);
        double num2 = Double.parseDouble(data2);

        double total = (num1*num2)/100;
        String sum=Double.toString(total);
        TextView t1 = (TextView) findViewById(R.id.textView6);
        //String tottal = total.toString();
        t1.setText(sum);
    }
}